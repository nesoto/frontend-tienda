import { useContext } from "react";
import CarritoContext from "../context/CarritoContext";


// Esto es de ejemplo, ya que debemos linkear con la base de datos
const Productos = () => {

    const { agregarAlCarrito } = useContext(CarritoContext);

    const listaDeFiguras = [
        {
            id: 1,
            nombre: "Naruto",
            precio: 20,
            imagen: "",
            descripcion: "Figura de Naruto Uzumaki, personaje principal del anime Naruto. Mide 15 cm de alto y está hecha de plástico resistente.",
        },
        {
            id: 2,
            nombre: "Luffy",
            precio: 30,
            imagen: "",
            descripcion: "Figura de Monkey D. Luffy, personaje principal del anime One Piece. Mide 20 cm de alto y está hecha de plástico resistente.",
        },
        {
            id: 3,
            nombre: "Goku",
            precio: 40,
            imagen: "",
            descripcion: "Figura de Goku, personaje principal del anime Dragon Ball. Mide 25 cm de alto y está hecha de plástico resistente.",
        }
    ];

    return (
        <div>
            <h1>Figuras Disponibles</h1>
            <div className="lista-figuras">
                {listaDeFiguras.map (figura => (
                    <div key={figura.id} className="figura">
                        <img src={figura.imagen} alt={figura.nombre} />
                        <h2>{figura.nombre}</h2>
                        <p>${figura.precio}</p>
                        <button onClick={() => agregarAlCarrito(figura)}>Agregar al carrito</button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Productos;