import Link from 'next/link';

const HomePage = () => {
  // Productos destacados
  const productosDestacados = [
    { id: 1, nombre: 'Figura de Naruto', precio: 25.99, descripcion: 'Figura detallada de Naruto Uzumaki.' },
    { id: 2, nombre: 'Figura de Luffy', precio: 30.50, descripcion: 'Figura de Monkey D. Luffy, Rey de los Piratas.' },
    { id: 3, nombre: 'Figura de Goku', precio: 40.00, descripcion: 'Figura épica de Goku en modo Super Saiyan.' },
  ];

  return (
    <div className="container">
      <h1 class="font-bold font-serif text-xl">Bienvenido a OtakuBox</h1>
      <p style={{ textAlign: 'center' }}>Descubre tus personajes favoritos y colecciona las mejores figuras de anime.</p>
      <div className="lista-figuras">
        {productosDestacados.map((producto) => (
          <div key={producto.id} className="card">
            <h2>{producto.nombre}</h2>
            <p>Precio: ${producto.precio.toFixed(2)}</p>
            <p>{producto.descripcion}</p>
          </div>
        ))}
      </div>
      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        <Link href="/productos">
          Ver mas productos
        </Link>
      </div>
    </div>
  );
};

export default HomePage;
