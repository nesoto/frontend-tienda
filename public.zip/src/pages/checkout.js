import { useState, useContext } from 'react';
import CarritoContext from '../context/CarritoContext';

const Checkout = () => {
  // Estado del formulario
  const [nombre, setNombre] = useState('');
  const [direccion, setDireccion] = useState('');
  const [correo, setCorreo] = useState('');

  // Obtener los productos del carrito
  const { carrito } = useContext(CarritoContext);

  // Manejar el envío del formulario
  const handleSubmit = (e) => {
    e.preventDefault();
    if (carrito.length === 0) {
      toast.error('El carrito está vacío');
      return;
    }
    toast.success('Compra realizada con éxito');
    console.log({ nombre, direccion, correo, carrito });
  }

  // Calcular el total de la compra
  const total = carrito.reduce((acc, producto) => acc + producto.precio * producto.cantidad, 0);

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold text-center mb-6">Checkout</h1>

      {/* Resumen del Carrito */}
      <div className="mb-6 bg-white p-4 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4">Resumen del Carrito</h2>
        {carrito.length === 0 ? (
          <p>El carrito está vacío.</p>
        ) : (
          <ul>
            {carrito.map((producto) => (
              <li key={producto.id} className="flex justify-between border-b py-2">
                <span>{producto.nombre} (x{producto.cantidad})</span>
                <span>${(producto.precio * producto.cantidad).toFixed(2)}</span>
              </li>
            ))}
          </ul>
        )}
        <h3 className="text-xl font-bold mt-4">Total: ${total.toFixed(2)}</h3>
      </div>

      {/* Formulario de Checkout */}
      <form onSubmit={handleSubmit} className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-md">
        <div className="mb-4">
          <label className="block text-gray-700 font-bold mb-2" htmlFor="nombre">
            Nombre Completo
          </label>
          <input
            type="text"
            id="nombre"
            className="w-full p-2 border border-gray-300 rounded"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            required
          />
        </div>

        <div className="mb-4">
          <label className="block text-gray-700 font-bold mb-2" htmlFor="direccion">
            Dirección
          </label>
          <input
            type="text"
            id="direccion"
            className="w-full p-2 border border-gray-300 rounded"
            value={direccion}
            onChange={(e) => setDireccion(e.target.value)}
            required
          />
        </div>

        <div className="mb-4">
          <label className="block text-gray-700 font-bold mb-2" htmlFor="correo">
            Correo Electrónico
          </label>
          <input
            type="email"
            id="correo"
            className="w-full p-2 border border-gray-300 rounded"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-orange-900 text-white py-2 rounded hover:bg-orange-950"
        >
          Realizar Compra
        </button>
      </form>
    </div>
  );
};

export default Checkout;
