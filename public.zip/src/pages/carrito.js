import Carrito from "../components/Carrito";

const CarritoPage = () => {
    return (
        <div>
            <Carrito />
        </div>
    );
};

export default CarritoPage;